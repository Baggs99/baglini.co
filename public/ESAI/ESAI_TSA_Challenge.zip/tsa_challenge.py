from pathlib import Path
from itertools import combinations
from math import radians, sin, cos, asin, sqrt
from textwrap import wrap
import polars as pl

DATA = Path("~/esai_2026/data/TSA").expanduser()
TSA = DATA / "tsa_checkpoint.parquet"
COORDS = DATA / "apt_lat_lon.parquet"


def first(df):
    return df.row(0, named=True)


def haversine(lat1, lon1, lat2, lon2):
    """Great-circle distance in miles."""
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1

    value = (
        sin(dlat / 2) ** 2
        + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    )

    return 3958.8 * 2 * asin(sqrt(value))


def closest_pair(df):
    rows = list(df.drop_nulls(["lat", "lon"]).iter_rows(named=True))
    best = None

    for a, b in combinations(rows, 2):
        distance = haversine(
            a["lat"],
            a["lon"],
            b["lat"],
            b["lon"],
        )

        if best is None or distance < best[0]:
            best = (distance, a["Airport"], b["Airport"])

    return best


def print_report(answers):
    width = 105

    lines = [
        "=" * width,
        "TSA / AIRBNB CHALLENGE — FINAL ANSWERS".center(width),
        "=" * width,
    ]

    for letter, answer in answers:
        wrapped = wrap(answer, width=width - 7) or [""]

        lines.append(f"{letter:<3} | {wrapped[0]}")

        for continuation in wrapped[1:]:
            lines.append(f"    | {continuation}")

        lines.append("-" * width)

    report = "\n".join(lines)
    print(report)

    Path("tsa_answers.txt").write_text(report, encoding="utf-8")
    print("\nSaved: tsa_answers.txt")


def main():
    # ---------- Load and normalize ----------
    raw = (
        pl.scan_parquet(TSA)
        .filter(
            pl.col("Pax").is_not_null()
            & (pl.col("Pax") >= 0)
        )
        .with_columns(
            pl.col("Date").dt.year().alias("year"),
            pl.col("Date").dt.month().alias("month"),
            pl.col("Date").dt.weekday().alias("weekday"),
            pl.col("Hour")
            .str.slice(0, 2)
            .cast(pl.Int8)
            .alias("hour"),
        )
    )

    # One smaller airport/date table reused for most questions.
    daily = (
        raw.group_by(["Date", "Airport", "State"])
        .agg(pl.col("Pax").sum())
        .collect(engine="streaming")
        .with_columns(
            pl.col("Date").dt.year().alias("year"),
            pl.col("Date").dt.month().alias("month"),
            pl.col("Date").dt.weekday().alias("weekday"),
        )
    )

    # ---------- Questions requiring raw checkpoint/hour data ----------
    a_query = (
        raw.sort("Pax", descending=True)
        .select(
            "Date",
            "Hour",
            "Airport",
            "Checkpoint",
            "Pax",
        )
        .head(1)
    )

    d_query = (
        raw.group_by("hour")
        .agg(pl.col("Pax").sum())
        .sort("Pax", descending=True)
        .head(1)
    )

    g_query = (
        raw.filter(
            (pl.col("year") == 2025)
            & (pl.col("hour") == 22)
        )
        .group_by("Airport")
        .agg(pl.col("Pax").sum())
        .sort("Pax", descending=True)
        .head(1)
    )

    j_query = (
        raw.filter(
            (pl.col("year") == 2015)
            & (pl.col("month") == 1)
            & (pl.col("Date").dt.day() == 1)
            & (pl.col("hour") == 0)
        )
        .group_by("Airport")
        .agg(pl.col("Pax").sum())
        .sort("Pax", descending=True)
        .head(1)
    )

    a, d, g, j = pl.collect_all(
        [a_query, d_query, g_query, j_query],
        engine="streaming",
    )

    # ---------- Annual airport totals ----------
    annual = (
        daily.group_by(["Airport", "year"])
        .agg(pl.col("Pax").sum())
    )

    years = (
        annual.group_by("Airport")
        .agg(
            pl.col("Pax")
            .filter(pl.col("year") == 2018)
            .sum()
            .alias("y2018"),

            pl.col("Pax")
            .filter(pl.col("year") == 2021)
            .sum()
            .alias("y2021"),

            pl.col("Pax")
            .filter(pl.col("year") == 2022)
            .sum()
            .alias("y2022"),

            pl.col("Pax")
            .filter(pl.col("year") == 2023)
            .sum()
            .alias("y2023"),

            pl.col("Pax")
            .filter(pl.col("year") == 2024)
            .sum()
            .alias("y2024"),
        )
    )

    # ---------- A ----------
    a_row = first(a)

    if isinstance(a_row["Checkpoint"], bytes):
        a_row["Checkpoint"] = a_row["Checkpoint"].decode(
            "utf-8",
            errors="replace",
        )

    # ---------- B ----------
    b = (
        daily.filter(pl.col("Airport") == "MIA")
        .sort("Pax", descending=True)
        .head(1)
    )
    b_row = first(b)

    # ---------- C ----------
    c = (
        annual.filter(pl.col("year") == 2024)
        .sort("Pax", descending=True)
        .head(1)
    )
    c_row = first(c)

    # ---------- D ----------
    d_row = first(d)

    # ---------- E ----------
    e = (
        years.filter(pl.col("y2021") > 0)
        .with_columns(
            (
                (pl.col("y2024") / pl.col("y2021") - 1)
                * 100
            ).alias("growth_pct")
        )
        .sort("growth_pct", descending=True)
        .head(1)
    )
    e_row = first(e)

    # ---------- F ----------
    f = (
        years.with_columns(
            (
                pl.col("y2024") - pl.col("y2023")
            ).alias("growth_level")
        )
        .sort("growth_level", descending=True)
        .head(1)
    )
    f_row = first(f)

    # ---------- G ----------
    g_row = first(g)

    # ---------- H ----------
    weekday_totals = (
        daily.filter(pl.col("year") == 2022)
        .group_by(["Airport", "weekday"])
        .agg(pl.col("Pax").sum())
    )

    busiest_weekday = (
        weekday_totals
        .sort(
            ["Airport", "Pax"],
            descending=[False, True],
        )
        .unique(
            "Airport",
            keep="first",
            maintain_order=True,
        )
    )

    h = (
        busiest_weekday
        .filter(pl.col("weekday") == 5)
        .join(
            years.select("Airport", "y2022"),
            on="Airport",
        )
        .sort("y2022", descending=True)
        .head(1)
    )
    h_row = first(h)

    # ---------- I ----------
    weekday_averages = (
        daily.group_by(["Airport", "weekday"])
        .agg(
            pl.col("Pax")
            .mean()
            .alias("avg_daily")
        )
    )

    consistency = (
        weekday_averages
        .group_by("Airport")
        .agg(
            pl.col("avg_daily")
            .var()
            .alias("weekday_variance"),

            pl.col("weekday")
            .n_unique()
            .alias("weekday_count"),
        )
        .filter(pl.col("weekday_count") == 7)
    )

    i = consistency.sort("weekday_variance").head(1)
    i_row = first(i)

    i_weekdays = (
        weekday_averages
        .filter(pl.col("Airport") == i_row["Airport"])
        .sort("weekday")
    )

    # ---------- J ----------
    j_row = first(j)

    # ---------- K ----------
    k = (
        daily.filter(pl.col("year") == 2024)
        .group_by(["State", "month"])
        .agg(pl.col("Pax").sum())
        .group_by("State")
        .agg(
            pl.col("Pax")
            .filter(pl.col("month") == 3)
            .sum()
            .alias("March"),

            pl.col("Pax")
            .filter(pl.col("month") == 7)
            .sum()
            .alias("July"),
        )
        .with_columns(
            (
                pl.col("July") - pl.col("March")
            ).alias("difference")
        )
        .filter(pl.col("difference") > 0)
        .sort("difference", descending=True)
    )

    k_states = ", ".join(
        f"{row['State']} (+{row['difference']:,.0f})"
        for row in k.iter_rows(named=True)
    )

    # ---------- L ----------
    l = (
        years.filter(pl.col("y2018") > 100_000)
        .with_columns(
            (
                (pl.col("y2024") / pl.col("y2018") - 1)
                * 100
            ).alias("change_pct")
        )
        .sort("change_pct")
        .head(1)
    )
    l_row = first(l)

    # ---------- Airport coordinates ----------
    states = (
        daily.select("Airport", "State")
        .unique("Airport")
    )

    coordinates = (
        pl.read_parquet(COORDS)
        .rename({"apt": "Airport"})
        .filter(
            pl.col("lat").is_between(-90, 90)
            & pl.col("lon").is_between(-180, 180)
        )
        .unique("Airport")
    )

    metadata = states.join(
        coordinates,
        on="Airport",
        how="inner",
    )

    # ---------- M ----------
    m = closest_pair(
        metadata.filter(pl.col("State") == "CA")
    )

    # ---------- N ----------
    n_pool = (
        years.filter(pl.col("y2024") > 1_000_000)
        .join(
            metadata,
            on="Airport",
            how="inner",
        )
    )

    n = closest_pair(n_pool)

    # ---------- O ----------
    candidates = (
        years.filter(pl.col("y2021") > 0)
        .with_columns(
            (
                pl.col("y2024") / pl.col("y2021") - 1
            ).alias("pct_growth"),

            (
                pl.col("y2024") - pl.col("y2023")
            ).alias("level_growth"),
        )
        .join(
            consistency.select(
                "Airport",
                "weekday_variance",
            ),
            on="Airport",
            how="inner",
        )
        .join(
            metadata,
            on="Airport",
            how="inner",
        )
    )

    traffic_points = list(
        candidates.select(
            "Airport",
            "lat",
            "lon",
            "y2024",
        ).iter_rows(named=True)
    )

    nearby_demand = []

    for airport in candidates.iter_rows(named=True):
        total = sum(
            other["y2024"]
            for other in traffic_points
            if other["Airport"] != airport["Airport"]
            and haversine(
                airport["lat"],
                airport["lon"],
                other["lat"],
                other["lon"],
            ) <= 100
        )

        nearby_demand.append(total)

    candidates = candidates.with_columns(
        pl.Series("nearby_demand", nearby_demand)
    )

    denominator = max(candidates.height - 1, 1)

    candidates = (
        candidates
        .with_columns(
            (
                (pl.col("y2024").rank() - 1)
                / denominator
            ).alias("volume_score"),

            (
                (pl.col("pct_growth").rank() - 1)
                / denominator
            ).alias("pct_score"),

            (
                (pl.col("level_growth").rank() - 1)
                / denominator
            ).alias("level_score"),

            (
                1
                - (
                    (pl.col("weekday_variance").rank() - 1)
                    / denominator
                )
            ).alias("consistency_score"),

            (
                (pl.col("nearby_demand").rank() - 1)
                / denominator
            ).alias("nearby_score"),
        )
        .with_columns(
            (
                0.35 * pl.col("volume_score")
                + 0.25 * pl.col("pct_score")
                + 0.15 * pl.col("level_score")
                + 0.10 * pl.col("consistency_score")
                + 0.15 * pl.col("nearby_score")
            ).alias("final_score")
        )
    )

    top5 = (
        candidates
        .select(
            "Airport",
            "State",
            "y2024",
            "pct_growth",
            "level_growth",
            "weekday_variance",
            "nearby_demand",
            "final_score",
        )
        .sort("final_score", descending=True)
        .head(5)
    )

    winner = first(top5)

    # ---------- Final answer sheet ----------
    answers = [
        (
            "A",
            f"{a_row['Airport']} — {a_row['Checkpoint']} on "
            f"{a_row['Date']:%Y-%m-%d} at {a_row['Hour']}; "
            f"{a_row['Pax']:,.0f} passengers.",
        ),
        (
            "B",
            f"{b_row['Date']:%Y-%m-%d}; "
            f"{b_row['Pax']:,.0f} passengers departed MIA.",
        ),
        (
            "C",
            f"{c_row['Airport']}; "
            f"{c_row['Pax']:,.0f} passengers in 2024.",
        ),
        (
            "D",
            f"{int(d_row['hour']):02d}:00–"
            f"{int(d_row['hour']):02d}:59; "
            f"{d_row['Pax']:,.0f} passengers overall.",
        ),
        (
            "E",
            f"{e_row['Airport']}; "
            f"{e_row['growth_pct']:,.1f}% growth "
            f"({e_row['y2021']:,.0f} in 2021 → "
            f"{e_row['y2024']:,.0f} in 2024).",
        ),
        (
            "F",
            f"{f_row['Airport']}; increase of "
            f"{f_row['growth_level']:,.0f} passengers "
            f"({f_row['y2023']:,.0f} in 2023 → "
            f"{f_row['y2024']:,.0f} in 2024).",
        ),
        (
            "G",
            f"{g_row['Airport']}; "
            f"{g_row['Pax']:,.0f} passengers from "
            "10:00–10:59pm in 2025.",
        ),
        (
            "H",
            f"{h_row['Airport']}; Friday was its busiest weekday, "
            f"with {h_row['y2022']:,.0f} total passengers in 2022.",
        ),
        (
            "I",
            f"{i_row['Airport']}; lowest variance across its "
            f"seven weekday averages "
            f"({i_row['weekday_variance']:,.2f}).",
        ),
        (
            "J",
            f"{j_row['Airport']}; "
            f"{j_row['Pax']:,.0f} passengers during the midnight "
            "hour on January 1, 2015.",
        ),
        (
            "K",
            k_states or "No states had higher July traffic than March.",
        ),
        (
            "L",
            f"{l_row['Airport']}; "
            f"{l_row['change_pct']:,.1f}% change "
            f"({l_row['y2018']:,.0f} in 2018 → "
            f"{l_row['y2024']:,.0f} in 2024).",
        ),
        (
            "M",
            f"{m[1]} and {m[2]}; "
            f"{m[0]:,.1f} miles apart.",
        ),
        (
            "N",
            f"{n[1]} and {n[2]}; "
            f"{n[0]:,.1f} miles apart among airports above "
            "1,000,000 passengers in 2024.",
        ),
        (
            "O",
            f"Recommend {winner['Airport']} ({winner['State']}). "
            f"It ranks first on the traffic, growth, consistency, "
            f"and nearby-demand heuristic with a score of "
            f"{winner['final_score']:.3f}. This is a targeting "
            "heuristic, not a causal estimate.",
        ),
    ]

    print_report(answers)

    print("\nTop five campaign candidates:")
    print(top5)

    print("\nWeekday averages for answer I:")
    print(i_weekdays)

    # Makes all results available to the notebook.
    return locals()


if __name__ == "__main__":
    main()